title: Windows下svn hook触发Python脚本通知钉钉
date: '2019-11-12 16:09:23'
updated: '2019-11-12 16:09:23'
tags: [visualsvn, svnhook, hook, python]
permalink: /articles/2019/11/12/1573546163220.html
---
![](https://img.hacpai.com/bing/20190831.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在Windows下SVN Server使用HOOK触发连接时遇到不小困难。
首先对windows命令集不熟悉，命令中一些不必要的空格造成不小麻烦；其次由于需要获取SVN提交内容，而`looksvn info` 命令中获取到的结果是带有换行的结果，在windows bat 中不容易获取，且curl命令调试困难，所以改用触发Python来达到目的。

首先在 `仓库\hook\post-commit.cmd`钩子中编辑：
```
set REPOS=%1
set TXN=%2         

set SVNLOOK="%VISUALSVN_SERVER%\bin\svnlook.exe"

YouPythonPath\python.exe %1\hooks\svn-hook.py %SVNLOOK% %2 %1

```
使用python获取到需要参数 SVNLOOK位置 版本号 仓库
**注意此时提交操作并不能触发到Python脚本
由于svn server没有足够权限
提示 failed exit code 1 with no output**
使用 WIN + R 打开 services.msc 
![E7C16820F8AF3CE6808836942C9F5B1A.png](https://img.hacpai.com/file/2019/11/E7C16820F8AF3CE6808836942C9F5B1A-d95b2482.png)
右键属性变更为：
![59CEDF5E4B78FE5BCC5369D534927857.png](https://img.hacpai.com/file/2019/11/59CEDF5E4B78FE5BCC5369D534927857-9cd00aad.png)

下面可以正常使用属性的Python编写触发代码了

```
#获取参数
args = sys.argv
svnlook = args[1]
ver = args[2]
rep = args[3]

#获取执行结果
commond = svnlook + ' info -r ' + ver +' ' + rep
result = os.popen(commond).read()

#结构化结果
result_datas = result.split('\n')
#用户名
user = result_datas[0]
#仓库名称
res = rep.split('\\')[-1]
#版本号
ver = ver
#提交的commit message
logs = result_datas[3]
#提交时间
time = result_datas[1]
#仓库链接
paths = rep.split('\\')[1:]
url = 'ip/' + '/'.join(paths)

#看看提交的内容中有没有@人
pattern = re.compile(r'(?<=@)[^\s]+\s?')
re_result = pattern.findall(logs)

#为了省事直接使用本地json映射了svn username 和 钉钉联系电话
contact = []
with open(rep+'/hooks/contact.json', encoding='utf-8') as f:
    data = json.load(f)
    print(type(data))
    for name in re_result:
        del_space_name = name.strip()
        print(del_space_name in data)
        if (del_space_name in data):
            contact.append(data[del_space_name])

生成markdown内容
content = f'#### {user}\n\n'
content += f'> 更新仓库:{res}\n\n'
content += f'> 版本:{ver}\n\n'
content += f'> 更新内容:{logs}\n\n'
content += f'###### {time}发布 \n\n'
content += f'###### [详情]({url})'



def send_request(text,contact):
    # Request
    # POST https://oapi.dingtalk.com/robot/send

    try:
        response = requests.post(
            url="https://oapi.dingtalk.com/robot/send",
            params={
                "access_token": "you token",
            },
            headers={
                "Content-Type": "application/json",
            },
            data=json.dumps({
                "msgtype": "markdown",
                "markdown": {
                    "title": user + "更新通知",
                    "text": 'text
                },
                "at":{
                    "atMobiles":contact,
                    "isAtAll":0
                }
            })
        )
        print('Response HTTP Status Code: {status_code}'.format(
            status_code=response.status_code))
        print('Response HTTP Response Body: {content}'.format(
            content=response.content))
    except requests.exceptions.RequestException:
        print('HTTP Request failed')

#发送
send_request(content,contact)

```
这时只要仓库有更新动作就可以通知到钉钉群中的人啦（减少产品经理更改文档没有及时通知UI或开发造成的撕逼

