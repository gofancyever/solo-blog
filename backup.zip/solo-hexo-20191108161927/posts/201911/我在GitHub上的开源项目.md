title: 我在 GitHub 上的开源项目
date: '2019-11-08 15:55:26'
updated: '2019-11-08 15:55:26'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [OEPopVideoController](https://github.com/ofEver/OEPopVideoController) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/ofEver/OEPopVideoController/watchers "关注数")&nbsp;&nbsp;[⭐️`17`](https://github.com/ofEver/OEPopVideoController/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/ofEver/OEPopVideoController/network/members "分叉数")</span>

基于GPUImage 微信小视屏



---

### 2. [OEVoiceKeyboard](https://github.com/ofEver/OEVoiceKeyboard) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/OEVoiceKeyboard/watchers "关注数")&nbsp;&nbsp;[⭐️`5`](https://github.com/ofEver/OEVoiceKeyboard/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/OEVoiceKeyboard/network/members "分叉数")</span>

基于科大讯飞语音识别键盘



---

### 3. [OECustomDatePicker](https://github.com/ofEver/OECustomDatePicker) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/OECustomDatePicker/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/ofEver/OECustomDatePicker/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/OECustomDatePicker/network/members "分叉数")</span>





---

### 4. [OEJsonToModel](https://github.com/ofEver/OEJsonToModel) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/OEJsonToModel/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ofEver/OEJsonToModel/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/OEJsonToModel/network/members "分叉数")</span>





---

### 5. [WorkUpFun](https://github.com/ofEver/WorkUpFun) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/WorkUpFun/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ofEver/WorkUpFun/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ofEver/WorkUpFun/network/members "分叉数")</span>





---

### 6. [XMPP-ReactiveCocoa](https://github.com/ofEver/XMPP-ReactiveCocoa) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/XMPP-ReactiveCocoa/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ofEver/XMPP-ReactiveCocoa/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/XMPP-ReactiveCocoa/network/members "分叉数")</span>





---

### 7. [Ever-WTAssistant](https://github.com/ofEver/Ever-WTAssistant) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/Ever-WTAssistant/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ofEver/Ever-WTAssistant/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/Ever-WTAssistant/network/members "分叉数")</span>





---

### 8. [solo-blog](https://github.com/ofEver/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ofEver/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://blog.sstar.xin`](http://blog.sstar.xin "项目主页")</span>

超级豆就是我 - 打杂



---

### 9. [ofever.github.io](https://github.com/ofEver/ofever.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/ofever.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ofEver/ofever.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/ofever.github.io/network/members "分叉数")</span>





---

### 10. [CareOfMySelf](https://github.com/ofEver/CareOfMySelf) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ofEver/CareOfMySelf/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ofEver/CareOfMySelf/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ofEver/CareOfMySelf/network/members "分叉数")</span>



