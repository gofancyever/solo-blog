title: Jenkins触发url时获取POST内数据
date: '2019-08-30 11:52:20'
updated: '2019-09-09 15:25:30'
tags: [Jenkins, CI, 阿里云镜像服务, Docker]
permalink: /articles/2019/08/30/1567137140452.html
---
在使用jenkin + Docker + 阿里云镜像部署项目时需要在服务器做以下操作
```
sudo docker login --username=username --password=password registry.cn-beijing.aliyuncs.com
sudo docker pull image:tag
sudo docker run --rm --name projectName -d -p ****:**** image:tag
```
此时Jenkins需要动态获取tag参数实现自动部署

阿里云镜像服务触发器中当调用链接时会发送以下POST信息：
```
{
    "push_data": {
        "digest": "sha256:457f4aa83fc9a6663ab9d1b0a6e2dce25a12a943ed5bf2c1747c58d48bbb4917", 
        "pushed_at": "2016-11-29 12:25:46", 
        "tag": "latest"
    }, 
    "repository": {
        "date_created": "2016-10-28 21:31:42", 
        "name": "repoTest", 
        "namespace": "namespace", 
        "region": "cn-hangzhou", 
        "repo_authentication_type": "NO_CERTIFIED", 
        "repo_full_name": "namespace/repoTest", 
        "repo_origin_type": "NO_CERTIFIED", 
        "repo_type": "PUBLIC"
    }
}
```
#####可以看到只要获取到POST信息中push_data.tag信息交给Jenkins构建就可以了,那么如何实现呢？

由于Jenkins自带Trigger有诸多限制(authentication 403 forbidden，参数化构建时遇到JSON数据处理不方便)等，所以使用Jenkins插件 [Generic Webhook Trigger Plugin](https://wiki.jenkins.io/display/JENKINS/Generic+Webhook+Trigger+Plugin) 
安装完成后再项目构建触发器做以下设置：
![image.png](https://user-gold-cdn.xitu.io/2019/8/30/16ce08242d9362d3?w=1240&h=817&f=png&s=198944)
根据JSON结构填写参数Expression我们需要获取tag参数，所以使用```$.push_data.tag```; 同理如果需要获取镜像名字可以用参数```$.repository.repo_full_name```获取
```Variable```参数就是指定Jenkins引用时的名字

设置Token
![image.png](https://user-gold-cdn.xitu.io/2019/8/30/16ce08242deb3e32?w=715&h=299&f=png&s=38548)
这时就可以使用```http://localhost:8080/jenkins/generic-webhook-trigger/invoke?token=abc123```
触发构建了

我们可以创建一个shell测试：
![image.png](https://img.hacpai.com/file/2019/09/image-0428a6ce.png)


使用工具测试一下：
![image.png](https://img.hacpai.com/file/2019/09/image-a8556e17.png)
可以看到构建日志中已经可以正常输出tag信息了
![image.png](https://img.hacpai.com/file/2019/09/image-5fdcc848.png)

这时就可以正常使用Docker更新镜像并运行了：
```
echo $tag
sudo docker stop projectName
sudo docker login --username=username --password=password registry.cn-beijing.aliyuncs.com
sudo docker pull image:$tag
sudo docker run --rm --name projectName -d -p ****:**** image:$tag
```



