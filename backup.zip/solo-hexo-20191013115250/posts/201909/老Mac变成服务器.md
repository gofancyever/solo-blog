title: 老Mac变成服务器
date: '2019-09-07 10:44:37'
updated: '2019-09-07 10:44:37'
tags: [Mac, frp]
permalink: /articles/2019/09/07/1567824277235.html
---
更换了Macbook pro，使用了近5年的Macbook Air终于宣告退役。最近将Air改造成一台私有服务器继续发挥它的价值。

所需要的配置和软件也很简单：
首先是SSH只要在Mac`偏好设置>共享>远程管理`中开启即可

![](https://user-gold-cdn.xitu.io/2019/9/7/16d09612b35914a0?w=233&h=401&f=png&s=20947)
由于一般宽带没有公网IP如果需要远程访问有三种方式：

1. 联系运营商索要公网IP,也有网友[破解光猫](https://user-gold-cdn.xitu.io/2019/9/7/16d0965062d88e1f)设置桥接方式获取到公网IP

2. 使用花生壳等内网穿透服务

3. 如果你有一台有公网IP的服务器可以使用[frp](https://github.com/fatedier/frp/blob/master/README_zh.md)


为了节省时间和自己服务灵活性我选择使用frp做内网穿透

1. 从frp [release](https://github.com/fatedier/frp/releases) 下载对应系统程序
解压后我们在需要做穿透的mac上编辑配置frpc.ini文件：
```
[common]
server_addr = 公网服务器的ip
server_port = 7000
admin_addr = 127.0.0.1
admin_port = 7400
token = token
tls_enable = true

#下面是我需要开启的服务，按自己需求自定义
[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 远程访问端口

[mysql]
type = tcp
local_port = 3306
remote_port = 远程访问端口

[postgres]
type = tcp
local_port = 5432
remote_port = 远程访问端口

[mongo]
type = tcp
local_port = 27017
remote_port = 远程访问端口

[jenkins]
type = tcp
local_port = 9090
remote_port = 远程访问端口

[jupyter]
type = tcp
local_port = 8888
remote_port = 远程访问端口

[aria2]
type = tcp
local_port = 6800
remote_port = 远程访问端口 

```
这里我在Air上穿透了测试数据库，并将一些服务(jenkins,jupyter)从原有的云服务器中转移到Air上减少资源占用，还开启的aria2下载工具，这样可以随时随地远程下载文件到我的Air中

配置完成后在终端运行

开启服务 ```./frpc -c frpc.ini```


接下载同样在有公网IP的服务器上下载客户端，编辑frps.ini,配置相对简单
```
[common]
bind_port = 7000
allow_ports = 需要穿透的端口，对应frpc的remote_port
token = 对应frpc的token
```
同样在服务端运行

`./frps -c frps.ini`

这时就实现了内网穿透，Air已经基本是一台服务器了

这时还需要两个软件让Air变成完全体，就是 [supervisor](http://supervisord.org/) 和 [noSleep](https://github.com/integralpro/nosleep/releases)

**在终端和公网服务器停掉之前运行的frpc和frps**

Supervisor一个进程管理工具，它可以很方便的监听、启动、停止、重启一个或多个进程。用Supervisor管理的进程，当一个进程意外被杀死，supervisort监听到进程死后，会自动将它重新拉起，很方便的做到进程自动恢复的功能。

Supervisor的安装方式有很对这里不再赘述

安装完成后在配置文件夹下(一般是/supervisor.d/) 

```touch frp.ini``` 或 ```frp.conf```

具体使用那个后退需要在/etc/supervisord.conf中最后一行查看也可自行修改配置路径
```
[include]
files = /etc/supervisor.d/*.conf
```
编辑frp.conf
```
[program:frpc]
command=/Users/***/frp_0.28.2_darwin_amd64/frpc -c /Users/***/frp_0.28.2_darwin_amd64/frpc.ini
user=you mac username
autostart=true
autorestart=true
startsecs=30
startretries=5
```
保存后运行
```supervisorctl update```
更新配置

```supervisorctl status```查看运行状态

这时当你的电脑重启或frp意外停止supervisor都会帮你重新启动frp

在公网服务器同样安装supervisor，添加配置`frps.conf`
```
[program:frps]
command=/etc/frp/frps -c /etc/frp/frps.ini
user=you ubuntu username
autostart=true
autorestart=true
startsecs=30
startretries=5
```
执行

```supervisorctl update```


这时通过

`ssh 公网user@公网IP -p 6000`

就可以访问你的内网Air了，如果你还穿透了其他服务如jenkins remote_port = 19090,使用 

`公网ip:19090`

就可以访问到Air中运行的jenkins服务

在实际使用过程中发现就算`偏好设置>节能设置`为永不休眠，盒盖也会发生断网情况，所以下载[noSleep](https://github.com/integralpro/nosleep/releases)并运行可以保持Air待机状态，这样就算合盖可以顺畅访问Air了。

Air这时就是一台带有公网IP的服务器了，想做什么就可以自由发挥了。


