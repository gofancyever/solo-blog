title: 如何同时设置tabbar圆角与阴影
date: '2019-09-03 09:56:42'
updated: '2019-09-03 09:56:42'
tags: [iOS, tabbar]
permalink: /articles/2019/09/03/1567475802208.html
---
```
    private let tabbarBackgroundView = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()

        tabbarBackgroundView.layer.cornerRadius = 20
        tabbarBackgroundView.backgroundColor = .white
        tabbarBackgroundView.layer.shadowColor = UIColor.black.cgColor
        tabbarBackgroundView.layer.shadowOffset = CGSize(width: 0, height: -5)
        tabbarBackgroundView.layer.shadowRadius = 20
        tabbarBackgroundView.clipsToBounds = false
        tabbarBackgroundView.layer.shadowOpacity = 0.5
        view.addSubview(tabbarBackgroundView)

        view.bringSubviewToFront(tabBar)

        tabBar.layer.cornerRadius = 20
        tabBar.layer.masksToBounds = true
        
        
        
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tabbarBackgroundView.frame = tabBar.frame
    }


```


![](https://user-gold-cdn.xitu.io/2019/9/3/16cf4d520ad77a25?w=358&h=161&f=png&s=9158)
